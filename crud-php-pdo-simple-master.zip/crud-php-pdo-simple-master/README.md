Simple PHP-MySQL CRUD (Add, Edit, Delete, View) using PDO
========

A simple and basic system to add, edit, delete and view using PHP and MySQL. 

Blog Article: [Simple PHP-MySQL CRUD (Add, Edit, Delete, View) using PDO](http://blog.chapagain.com.np/php-mysql-simple-crud-add-edit-delete-view-using-pdo/)

SQL script to create database and tables is present in **database.sql** file.

